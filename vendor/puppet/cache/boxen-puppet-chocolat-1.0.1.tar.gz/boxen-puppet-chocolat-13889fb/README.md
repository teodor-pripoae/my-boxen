# Chocolat Puppet Module for Boxen

Install [Chocolat](http://www.chocolatapp.com), a powerful text editor for Mac OS X.

## Usage

```puppet
include chocolat
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
