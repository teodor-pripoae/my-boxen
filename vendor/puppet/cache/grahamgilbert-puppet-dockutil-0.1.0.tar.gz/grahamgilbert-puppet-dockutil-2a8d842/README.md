# Puppet-Dockutil Module for Boxen

This module allows you to mange your dock using Kyle Crawford’s awesome dockutil.

## Usage

```puppet
dockutil { 'best example ever':
  salutation => 'fam'
}
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
